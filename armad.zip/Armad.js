(function () {
  // Основные ссылки на элементы DOM.
  const links = Array.from(document.querySelectorAll('.nav-link'));
  const sections = Array.from(document.querySelectorAll('main section[id]'));
  const revealNodes = Array.from(document.querySelectorAll('[data-reveal]'));
  const yearTarget = document.getElementById('year');
  const langButtons = Array.from(document.querySelectorAll('.lang-btn'));
  const textNodes = Array.from(document.querySelectorAll('[data-ru][data-kz]'));
  const placeholderNodes = Array.from(document.querySelectorAll('[data-ph-ru][data-ph-kz]'));
  const filterButtons = Array.from(document.querySelectorAll('.filter-btn'));
  const menuSearch = document.getElementById('menuSearch');
  const menuCategories = Array.from(document.querySelectorAll('.menu-category[data-category]'));
  const menuItems = Array.from(document.querySelectorAll('.menu-item[data-category]'));
  const bookingForm = document.getElementById('bookingForm');
  const dateInput = document.getElementById('bookDate');
  const hero = document.querySelector('.hero');
  const reduceMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  const prefersReducedMotion = reduceMotionQuery.matches;

  const state = {
    lang: localStorage.getItem('armad-lang') || 'ru',
    filter: 'all'
  };

  // Автоматически обновляет текущий год в подвале.
  if (yearTarget) {
    yearTarget.textContent = String(new Date().getFullYear());
  }

  // Запрещает выбор прошедшей даты для брони.
  if (dateInput) {
    dateInput.min = new Date().toISOString().split('T')[0];
  }

  const toLower = (value) => (value || '').toLocaleLowerCase(state.lang === 'kz' ? 'kk-KZ' : 'ru-RU');

  // Параллакс первого экрана от скролла и движения мыши.
  const setupParallax = () => {
    if (!hero || prefersReducedMotion) {
      return;
    }

    const updateParallaxByScroll = () => {
      const rect = hero.getBoundingClientRect();
      const viewportHeight = window.innerHeight || 1;
      const progress = Math.max(-1, Math.min(1, (rect.top + rect.height / 2 - viewportHeight / 2) / viewportHeight));
      hero.style.setProperty('--parallax-y', `${progress * 40}px`);
    };

    const updateParallaxByMouse = (event) => {
      const rect = hero.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width - 0.5) * 26;
      hero.style.setProperty('--parallax-x', `${x.toFixed(2)}px`);
    };

    updateParallaxByScroll();
    hero.addEventListener('mousemove', updateParallaxByMouse);
    hero.addEventListener('mouseleave', () => {
      hero.style.setProperty('--parallax-x', '0px');
    });
    window.addEventListener('scroll', updateParallaxByScroll, { passive: true });
    window.addEventListener('resize', updateParallaxByScroll);
  };

  // Переключает все переводимые тексты и placeholder между RU и KZ.
  const applyLanguage = (lang) => {
    state.lang = lang;
    document.documentElement.lang = lang;

    textNodes.forEach((node) => {
      const value = node.getAttribute(`data-${lang}`);
      if (value !== null) {
        node.textContent = value;
      }
    });

    placeholderNodes.forEach((node) => {
      const value = node.getAttribute(`data-ph-${lang}`);
      if (value !== null) {
        node.setAttribute('placeholder', value);
      }
    });

    langButtons.forEach((btn) => btn.classList.toggle('is-active', btn.dataset.lang === lang));
    localStorage.setItem('armad-lang', lang);
    applyMenuFilter();
  };

  // Комбинированная фильтрация меню: категория + поисковый запрос.
  const applyMenuFilter = () => {
    const query = toLower(menuSearch ? menuSearch.value.trim() : '');

    menuCategories.forEach((category) => {
      const categoryId = category.dataset.category;
      const categoryMatch = state.filter === 'all' || state.filter === categoryId;
      const categoryItems = Array.from(category.querySelectorAll('.menu-item'));
      let visibleCount = 0;

      categoryItems.forEach((item) => {
        const name = item.getAttribute(`data-name-${state.lang}`) || '';
        const searchMatch = !query || toLower(name).includes(query);
        const isVisible = categoryMatch && searchMatch;
        item.hidden = !isVisible;
        if (isVisible) {
          visibleCount += 1;
        }
      });

      category.hidden = visibleCount === 0;
    });
  };

  // Обработчики кнопок фильтра по категориям.
  filterButtons.forEach((button) => {
    button.addEventListener('click', () => {
      state.filter = button.dataset.filter || 'all';
      filterButtons.forEach((btn) => btn.classList.toggle('is-active', btn === button));
      applyMenuFilter();
    });
  });

  // Живой поиск по названию блюда.
  if (menuSearch) {
    menuSearch.addEventListener('input', applyMenuFilter);
  }

  // Обработчики переключения языка.
  langButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const lang = button.dataset.lang === 'kz' ? 'kz' : 'ru';
      applyLanguage(lang);
    });
  });

  // Форма брони: открывает WhatsApp с готовым текстом заявки.
  if (bookingForm) {
    bookingForm.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!bookingForm.checkValidity()) {
        bookingForm.reportValidity();
        return;
      }

      const name = document.getElementById('bookName')?.value.trim() || '';
      const phone = document.getElementById('bookPhone')?.value.trim() || '';
      const date = document.getElementById('bookDate')?.value || '';
      const time = document.getElementById('bookTime')?.value || '';
      const guests = document.getElementById('bookGuests')?.value || '';
      const note = document.getElementById('bookNote')?.value.trim() || '-';

      const message = state.lang === 'kz'
        ? [
            'ArMad бронь',
            `Аты: ${name}`,
            `Телефон: ${phone}`,
            `Күні: ${date}`,
            `Уақыты: ${time}`,
            `Қонақ саны: ${guests}`,
            `Пікір: ${note}`
          ].join('\n')
        : [
            'Бронь стола ArMad',
            `Имя: ${name}`,
            `Телефон: ${phone}`,
            `Дата: ${date}`,
            `Время: ${time}`,
            `Гостей: ${guests}`,
            `Комментарий: ${note}`
          ].join('\n');

      const waUrl = `https:wa.me/77071860202?text=${encodeURIComponent(message)}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');
    });
  }

  // Плавное появление блоков при скролле с небольшой задержкой по очереди.
  if (revealNodes.length) {
    revealNodes.forEach((node, index) => {
      node.style.setProperty('--reveal-delay', `${Math.min(index * 40, 360)}ms`);
    });

    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) {
            return;
          }
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        });
      },
      {
        threshold: 0.18,
        rootMargin: '0px 0px -8% 0px'
      }
    );

    revealNodes.forEach((node) => revealObserver.observe(node));
  }

  // Подсветка активного пункта меню при прокрутке секций.
  const linkById = new Map(
    links
      .map((link) => {
        const href = link.getAttribute('href') || '';
        return href.startsWith('#') ? [href.slice(1), link] : null;
      })
      .filter(Boolean)
  );

  const setActive = (id) => {
    links.forEach((link) => {
      link.classList.toggle('active', link === linkById.get(id));
    });
  };

  if (sections.length && links.length) {
    const navObserver = new IntersectionObserver(
      (entries) => {
        entries
          .filter((entry) => entry.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)
          .forEach((entry) => setActive(entry.target.id));
      },
      {
        rootMargin: '-38% 0px -45% 0px',
        threshold: [0.25, 0.5, 0.75]
      }
    );

    sections.forEach((section) => navObserver.observe(section));
  }

  // Управление прелоадером
  const preloader = document.getElementById('preloader');
  if (preloader) {
    // Скрыть прелоадер после загрузки страницы
    const hidePreloader = () => {
      setTimeout(() => {
        preloader.classList.add('is-hidden');
        // Удалить из DOM после анимации
        setTimeout(() => {
          preloader.remove();
        }, 800);
      }, 2000); // Показывать прелоадер минимум 2 секунды
    };

    if (document.readyState === 'complete') {
      hidePreloader();
    } else {
      window.addEventListener('load', hidePreloader);
    }
  }

  // Управление мобильным меню
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('nav');

  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      menuToggle.classList.toggle('is-active', isOpen);
      menuToggle.setAttribute('aria-expanded', String(isOpen));
    });

    // Закрыть меню при клике на ссылку
    links.forEach((link) => {
      link.addEventListener('click', () => {
        nav.classList.remove('is-open');
        menuToggle.classList.remove('is-active');
        menuToggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Закрыть меню при клике вне его
    document.addEventListener('click', (e) => {
      if (!nav.contains(e.target) && !menuToggle.contains(e.target)) {
        nav.classList.remove('is-open');
        menuToggle.classList.remove('is-active');
        menuToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Первичная инициализация.
  applyLanguage(state.lang === 'kz' ? 'kz' : 'ru');
  applyMenuFilter();
  setupParallax();
})();

